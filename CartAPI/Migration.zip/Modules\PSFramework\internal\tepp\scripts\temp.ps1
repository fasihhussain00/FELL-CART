﻿Register-PSFTeppScriptblock -Name 'PSFramework.Temp.ProviderName' -ScriptBlock {
	$script:tempItems.Providers.Keys
}